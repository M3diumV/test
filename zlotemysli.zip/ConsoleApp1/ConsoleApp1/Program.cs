﻿using System;
using zlota_mysl;

namespace mainProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            mysliKlasa mysli = new mysliKlasa();
            mysli.showMenu();
        }
    }
}